package com.becoder.UserApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.becoder.UserApp.bean.User;
import com.becoder.UserApp.dao.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
public User save(User user) {
		
		return userRepository.save(user);
	}

	public Optional<User> findById(int id) {

		return userRepository.findById(id);
	}
	
public boolean existsById(int id) {
		
		Optional<User> userOptional = userRepository.findById(id);
		
		if(userOptional.isEmpty()) {
			return false;
		}
		
		return true;
	}

public List<User> getUser(int id){
	userRepository.findById(id);
	return null;
}
}
