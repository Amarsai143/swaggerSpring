package com.becoder.UserApp.controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.becoder.UserApp.bean.User;
import com.becoder.UserApp.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	// creating user
	@PostMapping("/users")
	public ResponseEntity<String> createUser(@RequestBody User user) {
		try {
			User savedUser = userService.save(user);
			return new ResponseEntity<>("User with ID " + savedUser.getId() + " saved successfully",
					HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>("Failed to save user", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//retrieving user details based on the id
	@GetMapping("/users/{id}")
	public Optional<User> getUser(@PathVariable int id){
		if(userService.existsById(id)) {
			return userService.findById(id);
		}else {
			return Optional.empty();
		}
	}

}
